#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Oct 28 21:39:04 2019

@author: 201448617
"""

from sklearn import datasets
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
import numpy as np
from sklearn.externals import joblib
import matplotlib.pyplot as plt
#from sklearn.naive_bayes import GaussianNB


class NBClassifier(object):
    
    def __init__(self):
        self.y = []      #labels
        self.x = []      #the set of values for each attribute
        self.py = {}     #probability distribution of labels 
        self.pxy = {}    #Probability distribution of each attribute under each label       
        self.subData = {}    #divide the data by label
    
        
    def prob(self,element,arr):
        '''
        Calculate the probability of an element appearing in the array
        '''       
        prob = 0.0
        for a in arr:
            if element == a:
                prob += 1/len(arr)
                
        '''
        If the array does not contain the element, set the prob of the element to 0.001
        To prevent possible errors in the calculation
        '''
        if prob == 0.0:   
            prob = 0.001  
        return prob
     
            
    def getSub(self,x,y):
        '''
        Divide the data by labels
        '''       
        SubData = {}
        for i in range(len(x)):
            v = x[i]
            if (y[i] not in SubData):
                SubData[y[i]] = []
            SubData[y[i]].append(v)
        self.subData = SubData
            
    def getSample(self,k,Yj):
        '''
        get trainning data of the k th feature of label Yi
        '''       
        sampleList = []
        for i in range(len(self.subData[Yj])):
            sampleList.append(self.subData[Yj][i][k])
        return sampleList

                   
    def fit(self,x,y,X_featureList,y_classList):
        '''
        training model
        
        x: the data
        y: the target
        X_featureList: the set of values for each attribute
        y_classList: classes
        '''
        self.y = y_classList
        self.x = X_featureList
        #1. get p(y)
        for yi in self.y:
            self.py[yi] = self.prob(yi,y)
        self.getSub(x,y)
        #2. get p(x|y)
        for yi in self.y:
            self.pxy[yi] = {}
            for i in range(x.shape[1]):
                sample = self.getSample(i,yi) #data of the i th feature of label yi
                self.pxy[yi][i] = {}
                #get the probability distribution of this feature when y =yi
                for xi in self.x[i]:
                   pset = self.prob(xi,sample)
                   self.pxy[yi][i][xi] = pset
        return self
            
    
    def predict(self,x):
        '''
        prediction function
        '''
        y_list = []
        for m in range(x.shape[0]):
            yi = self.predict_one(x[m,:])
            y_list.append(yi)
        return np.array(y_list)
    
    def predict_one(self,x):
        '''
        predict a single data
        '''
        max_prob = 0.0
        max_yi = self.y[0]
        for yi in self.y:
            prob_y = self.py[yi]
            for i in range(len(x)):
                prob_x_y = self.pxy[yi][i][x[i]] #p(xi|y)
                prob_y *= prob_x_y               #p(x1|y)p(x2|y)...p(xn|y)p(y)
            if prob_y > max_prob:
                max_prob = prob_y
                max_yi = yi
        return max_yi

    def score(self,x,y):
        '''
        calculate the accuracy
        '''
        y_test = self.predict(x)
        score = 0.0
        for i in range(len(y)):
            if y_test[i] == y[i]:
                score += 1/len(y)
        return score 
    

def inputQuery(message):
  while True:
    try:
       userInput = int(input(message))       
    except ValueError:
       print("Not an integer! Try again. The range is (0,539)")
       continue
    else:
       return userInput 
       break 
    
                   

if __name__ == '__main__':
  #1.get the dataset
  digits = datasets.load_digits(return_X_y=False)
  X = digits.data
  y = digits.target
  classList = digits.target_names
  featureList = []
  #2.get the number of data entries for each class
  dataEntries = {}
  for i in range(len(X)):
      v = X[i]
      if (y[i] not in dataEntries):
          dataEntries[classList[i]] = []
      dataEntries[y[i]].append(v)
  dataEntryDict = {}
  for i in range(len(classList)):
      v = classList[i]
      dataEntryDict[v] = len(dataEntries[v])
  #3.featureList contains the range of values for each feature
  for i in range(X.shape[1]):
      featureList.append([0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16])
  #4.get the minimum and maximum values for each feature
  featureRange = {}
  for i in range(X.shape[1]):
      minAndMax = [min(list(set(X[:,i]))),max(list(set(X[:,i])))]
      featureRange[i] = minAndMax
  #5.split the dataset randomly
  X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=0)
  #6.print information of the dataset
  print(digits.DESCR) 
  print("*"*50)
  print("1. The number of data entries is", X.shape[0])
  print("2. The number of classes is", len(classList))
  print("3. The number of data entries for each classes:", dataEntryDict)
  print("4. In this dataset, the minimum and maximum values for each feature:", featureRange)
  print("5. the the train dataset and test dataset split is 7:3")
  #7.load the models
  #library_NB is from sklearn.navie_bayes_GaussianNB
  #clf_NB is an object of NBClassifier() 
  library_NB = joblib.load("Library_NB_model.m")
  clf_NB = joblib.load("NB_model.m")
  #8.show the accuracy of the two models
  y_pred = library_NB.predict(X_train)
  clf_pred = clf_NB.score(X_train,y_train)
  print("*"*50)
  print('Train Accuracy for library model: %.2f' % accuracy_score(y_train, y_pred))
  print("Train Accuracy for Navie Bayer model:%.2f" % clf_pred)
  y_pred2 = library_NB.predict(X_test)
  clf_pred2 = clf_NB.score(X_test,y_test)
  print('Test Accuracy for library model: %.2f' % accuracy_score(y_test, y_pred2))
  print("Test Accuracy for Navie Bayer model:%.2f" % clf_pred2)
  #9.compare the train error and test error of the two models:
  label_list = ['train', 'test']
  lib_1 = round(1 - accuracy_score(y_train, y_pred),2)
  lib_2 = round(1 - accuracy_score(y_test, y_pred2),2)
  NB_1 = round(1 - clf_pred,2)
  NB_2 = round(1 - clf_pred2,2)
  librarydata = [lib_1,lib_2]
  NBdata = [NB_1,NB_2]
  x = np.arange(2)
  rects1 = plt.bar(x, height=librarydata, width=0.4, color='red', label="Library_NB_model")
  rects2 = plt.bar(x+0.4, height=NBdata, width=0.4, color='green', label="NB_model")
  plt.ylim(0, 0.5)     #the range of y is (0,0.5)
  plt.ylabel("error rate")
  plt.xticks([index + 0.2 for index in x], label_list)
  plt.xlabel("NB model")
  plt.title("Comparison of the error rate")
  plt.legend()    
  # plt
  for rect in rects1:
    height = rect.get_height()
    plt.text(rect.get_x() + rect.get_width() / 2, height+0.1, str(height), ha="center", va="bottom")
  for rect in rects2:
    height = rect.get_height()
    plt.text(rect.get_x() + rect.get_width() / 2, height+0.1, str(height), ha="center", va="bottom")
  plt.show()
  print("*"*50)
  #10.Query from users:
  '''
  By changing the value of userQuery, users can query the test dataset
  Range: 0 <= userQuery <= 539
  '''
  userQuery = 539     
  lib = library_NB.predict(X_test[userQuery].reshape(1,-1))
  NB = clf_NB.predict(X_test[userQuery].reshape(1,-1))
  print("Query example:")
  print("Query from user(index of test dataset):",userQuery)
  print(" the true class:",y_test[userQuery],"\n","predicted by sklearn library model:",lib[0],"\n","predicted by Navie Bayer model",NB[0])
  userQuery = inputQuery("Query from user(please input an integer from 0 to 539) and press 'enter':")
  lib = library_NB.predict(X_test[userQuery].reshape(1,-1))
  NB = clf_NB.predict(X_test[userQuery].reshape(1,-1))
  print(" the true class:",y_test[userQuery],"\n","predicted by sklearn library model:",lib[0],"\n","predicted by Navie Bayer model",NB[0])
